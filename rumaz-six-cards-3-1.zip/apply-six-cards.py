#!/usr/bin/env python3
"""Surgical RuMaZ 3.1: four -> six homepage cards on existing staging feature branch.
Fails closed if expected source fragments diverge. No Supabase/db/env changes.
"""
from pathlib import Path
import re

ROOT=Path.cwd()
def file(path):
    p=ROOT/path
    if not p.is_file(): raise RuntimeError(f'Missing {path}')
    return p, p.read_text(encoding='utf-8')
def replace_one(text,old,new,label):
    n=text.count(old)
    if n!=1: raise RuntimeError(f'Expected one instance of {label}, found {n}')
    return text.replace(old,new,1)
def write(path,src):
    (ROOT/path).write_text(src,encoding='utf-8')

cards=[
  ('woning','Woning','home-woning.webp','i-home','Vrijstaande woning met tuin'),
  ('appartement','Appartement','home-appartement.webp','i-apartment','Woningen aan de kade'),
  ('huisje','Huisje','home-huisje.webp','i-home','Houten vakantiehuisje met terras'),
  ('camper','Camper','home-camper.webp','i-camper','Camper op een groene camping'),
  ('caravan','Caravan','home-caravan.webp','i-camper','Caravan met luifel op een kampeerplek'),
  ('boot','Boot','home-boot.webp','i-boat','Zeilboot aan de steiger'),
]
assert len({p[0] for p in cards})==6
# Existing 'check-in' is existing registration and place-add, never a new public endpoint.
card_html=[]
for code,label,photo,icon,alt in cards:
    card_html.append(
        f'<article class="place-choice"><img src="/assets/img/{photo}" alt="{alt}" '
        f'width="800" height="500" loading="lazy"/>'
        f'<div class="place-choice-copy"><svg class="symbol" aria-hidden="true">'
        f'<use href="#{icon}"/></svg><h3>{label}</h3>'
        f'<p>Start met {label} geselecteerd.</p>'
        f'<a class="btn" data-place-intent="{code}" '
        f'href="/app/account/registreren/?pleksoort={code}">'
        f'Naar check-in<span class="sr-only">: {label}</span></a></div></article>'
    )
section=('''<section class="home-choices" id="kies-plek" aria-labelledby="choicesTitle">'''
  '''<p class="home-kicker">Kies je plek</p><h2 id="choicesTitle" tabindex="-1">Welke plek wil je regelen?</h2>'''
  '''<p>Kies de pleksoort. De gegevens vul je zelf in.</p>'''
  '''<div class="place-choices" aria-label="Zes pleksoorten; veeg om de overige kaarten te zien" tabindex="0">'''
  +''.join(card_html)+'''</div></section>''')

path='site/app/index.html';p,s=file(path)
pat=r'<section class="home-choices" id="kies-plek" aria-labelledby="choicesTitle">[\s\S]*?</section>'
s,n=re.subn(pat,lambda m:section,s)
if n!=1:raise RuntimeError(f'Expected one homepage choices section, got {n}')
s=replace_one(s,'<option value="home">Huis</option><option value="chalet">Chalet</option>',
  '<option value="home">Woning</option><option value="chalet">Chalet</option><option value="huisje">Huisje</option>', 'select options')
write(path,s)

path='site/assets/js/rumaz3-intent.js';p,s=file(path)
old="const choices=Object.freeze({camper:{kind:'camper',label:'Camper'},chalet:{kind:'home',label:'Chalet'},appartement:{kind:'home',label:'Appartement'},boot:{kind:'boat',label:'Boot'}});"
new="const choices=Object.freeze({woning:{kind:'home',label:'Woning'},appartement:{kind:'home',label:'Appartement'},huisje:{kind:'home',label:'Huisje'},camper:{kind:'camper',label:'Camper'},caravan:{kind:'caravan',label:'Caravan'},boot:{kind:'boat',label:'Boot'},chalet:{kind:'home',label:'Chalet'}});"
s=replace_one(s,old,new,'intent mapping')
write(path,s)

path='site/assets/js/rumaz3-social.js';p,s=file(path)
s=replace_one(s,"const placeTypes={home:'Huis',chalet:'Chalet',appartement:'Appartement'", "const placeTypes={home:'Woning',chalet:'Chalet',huisje:'Huisje',appartement:'Appartement'",'form labels')
s=replace_one(s,"const niceType=t=>({home:'Huis',chalet:'Chalet',appartement:'Appartement'", "const niceType=t=>({home:'Woning',chalet:'Chalet',huisje:'Huisje',appartement:'Appartement'",'display labels')
# Form and storage both remain home for chalet/huisje/appartement. UI subtype stored in existing fields details.
for label in ['formKind','display subtype','store subtype']:
    s=replace_one(s,"['chalet','appartement']", "['chalet','huisje','appartement']", label)
s=replace_one(s,"selectTab('plek');chooseRole('own',code==='boot'?'boat':code);intent.clear();", "selectTab('plek');chooseRole('own',code==='woning'?'home':code==='boot'?'boat':code);intent.clear();",'selection routing')
write(path,s)

path='qa/homepage-intent.test.mjs';p,s=file(path)
s=replace_one(s,"const codes=['camper','chalet','appartement','boot'];", "const codes=['woning','appartement','huisje','camper','caravan','boot','chalet'];",'test intents')
s=replace_one(s,"assert.equal(d.querySelector('#typeInput').value,code==='boot'?'boat':code);", "assert.equal(d.querySelector('#typeInput').value,code==='woning'?'home':code==='boot'?'boat':code);",'test selection')
s=replace_one(s,"assert.equal(h.calls[0].type,['chalet','appartement'].includes(code)?'home':code==='boot'?'boat':code);", "assert.equal(h.calls[0].type,['woning','chalet','huisje','appartement'].includes(code)?'home':code==='boot'?'boat':code);",'test stored type')
s=replace_one(s,"if(['chalet','appartement'].includes(code))", "if(['chalet','huisje','appartement'].includes(code))",'test persisted subtype')
s=replace_one(s,".length,4);for(const a", ".length,6);for(const a",'test 6 cards')
write(path,s)

path='qa/homepage-auth.test.mjs';p,s=file(path)
s=replace_one(s,"['camper','chalet','appartement','boot']","['woning','appartement','huisje','camper','caravan','boot','chalet']",'test auth routes')
write(path,s)

for code,label,photo,icon,alt in cards:
    dest=ROOT/'site/assets/img'/photo
    if not dest.is_file() or dest.stat().st_size<10_000:raise RuntimeError(f'Missing optimized card photo: {dest}')
print('RuMaZ: 6 kaarten bijgewerkt, bestaande 3.1-bron intact, 6 images verified')
