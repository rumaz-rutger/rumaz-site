# RuMaZ 3.1 — zes kaarten (staging)

**Status:** voorbereid als gerichte vervolgpatch. Niet gepubliceerd, geen toegang tot `main` of productie nodig.

## Wat verandert

De bestaande vier horizontaal bladerbare homepagekaarten worden zes kaarten in deze volgorde:

1. Woning — formulier Woning; opgeslagen als bestaande `home`.
2. Appartement — hetzelfde woningformulier, maar eigen zichtbaar label en bestaande subtype `appartement`.
3. Huisje — hetzelfde woningformulier, zichtbaar Huisje, bestaande `home` met subtype `huisje` in de reeds aanwezige `fields` JSON-array.
4. Camper — bestaand camperformulier.
5. Caravan — dezelfde bestaande registratie- en Mijn plek-route, met Caravan geselecteerd en bestaande caravanvelden.
6. Boot — bestaand bootformulier.

Bestaande `chalet` links blijven geldig. Niet een nieuwe check-inpagina maken. Voor niet-ingelogde mensen: bestaande `/app/account/registreren/` met `?pleksoort=...`; voor ingelogde mensen: bestaande `/app/#plek` met vooraf ingevuld type. Typekeuze blijft bewaard in de huidige `RumazIntent`-opslag, zonder geheimen of persoonsgegevens. Er ontstaan géén plekken vóór de gebruiker bewust opslaat.

## Foto’s

Alle zes aangeleverde composities zijn gebruikt. Web-assets zijn 800×500 WebP-crops van de fotografische scènes (geen nieuwe AI-beelden). De ingebakken logo's, sluitssteenbeelden en teksten zijn buiten de crop gelaten om dubbeling en onleesbaarheid te voorkomen. Alle bestaande RuMaZ-logo’s en -illustraties in de site blijven onaangeroerd. Bij het appartement is het gezicht van het kind buiten de uitsnede gehouden.

## Wijzigingsbereik

Alleen:
- `site/app/index.html`
- `site/assets/js/rumaz3-intent.js`
- `site/assets/js/rumaz3-social.js`
- `qa/homepage-intent.test.mjs`
- `qa/homepage-auth.test.mjs`
- zes geoptimaliseerde bestanden in `site/assets/img/`.

**Geen wijzigingen** aan de database, Supabase-auth/keys, Mollie, Netlify-instellingen, bestaand hoofdmenu, hero, footer, maatschappelijke boodschap of andere websiteschermen.

## iPhone-upload als eerder

1. Download `rumaz-six-cards-3-1.zip` en sla op in Bestanden.
2. Upload het ZIP-bestand naar de **root** van de bestaande branch `feat/rumaz-homepage-3-1` in GitHub en commit.
3. Upload daarna `import-six-cards-31.yml` naar `.github/workflows/` op diezelfde branch. Die tweede commit start de bestaande GitHub Actions-route automatisch. **Niet naar `main` uploaden.**
4. Laat de importjob de uitgepakte beelden en een beperkte codecorrectie toepassen; de job draait `npm test`, statische check en stagingbuild. De job commit alleen naar de featurebranch.
5. Netlify kan automatisch bouwen, anders `Trigger deploy → Deploy site` op `rumaz-staging` (niet op `rumaz`).
6. Test zes kaarten op je iPhone, waaronder registratie, ontvangen van mail, bewaarde plek, terugkeer en navigatie. Pas na akkoord merge naar `main`.

De Actions-workflow controleert de exacte branch, huidige vastgestelde code-basis, de pakketchecksum, ontbrekende assets en de automatische tests. Als de branch in de tussentijd veranderd is, moet hij bewust aangepast worden: geen force-push, geen blinde overschrijving.
